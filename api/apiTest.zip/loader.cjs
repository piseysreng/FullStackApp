(async () => {
  await import('./dist/src/index.js');
})();